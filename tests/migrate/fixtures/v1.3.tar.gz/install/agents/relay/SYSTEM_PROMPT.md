You are relay (fixture).
