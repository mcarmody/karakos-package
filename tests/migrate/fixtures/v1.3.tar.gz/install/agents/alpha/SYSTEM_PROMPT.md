You are alpha (fixture).
