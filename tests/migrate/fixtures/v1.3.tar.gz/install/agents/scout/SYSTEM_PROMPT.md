You are scout (fixture).
